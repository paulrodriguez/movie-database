/*
this query uses a subquery to select actor ids from the cross product of relations Movie and MovieActor where the movie ids
are the same in both relations and the title is 'Die Another Day'. we then use this temporary relation and take a cross
product with the Actor relation and check that actor ids are the same to find which actors appeared in the movie selected
*/
SELECT CONCAT(first, ' ', last) AS Name 
FROM Actor A, (SELECT aid FROM Movie, MovieActor WHERE Movie.id=MovieActor.mid AND Movie.title='Die Another Day') M 
WHERE A.id=M.aid;
/*
--this will first use a subquery to group all actors in MovieActor relation by their actor id and then count how many times the same actor id appeared in the relation, then it will return the number of actors that appeared more than once
*/
SELECT COUNT(*) AS count_of_actors 
FROM (SELECT aid FROM MovieActor 
GROUP BY aid 
HAVING COUNT(aid)>=2) M;

/*
--this selects all people who were both actors and directors who have passed away and prints out first and last names, as well as the date they passed away
*/
SELECT Actor.last, Actor.first, Actor.dod
FROM Actor, Director
WHERE Director.id=Actor.id AND Director.dod IS NOT NULL
ORDER BY Actor.last, Actor.first;

